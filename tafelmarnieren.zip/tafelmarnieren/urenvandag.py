for i in range(24):
    if i > 11:
        print(f"{i}.00 pm")
    else:
        print(f"{i}.00 am")