tafel = input ("welke tafel wilt u zien?\n")
for i in range (11):
    print(i * int(tafel))