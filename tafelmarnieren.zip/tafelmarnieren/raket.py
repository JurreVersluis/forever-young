import time
for i in range(30):
    time.sleep(1)
    print (30 - i)
print("En we zijn gelanceerd!")